let name = "Apiwat"
let grade = 15
let final = 20
var sum = grade + final
sum = sum + 1
