
let array : Array<Int> = [1,2,3,4]
let dictionary : Dictionary <String,Int> = ["dog":1,"elephen":2]

//let arr : Array<String> =[""]
let dictionary2 : Dictionary <String,String> = ["Bangkok":"Bkk","Suwannaphoom":"AWP","London":"LD"]
airports["apl"]="sdfghjkl"