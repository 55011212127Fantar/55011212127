
import UIKit

var frinename = ["ing","som"]
var idfrine = [55011212088,55011212127]
var iddaa = idfrine [0]+1

idfrine += [55011212182]
idfrine += [55011212092,55011212005]

if(true){
    println("Test")
}
