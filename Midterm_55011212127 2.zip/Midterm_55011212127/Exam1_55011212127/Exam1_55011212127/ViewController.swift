//
//  ViewController.swift
//  Exam1_55011212127
//
//  Created by Student on 10/10/2557 BE.
//  Copyright (c) 2557 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet var text1: UITextField!
    @IBOutlet var text2: UITextField!
    @IBOutlet var text3: UITextField!
    @IBOutlet var text4: UITextField!
    @IBOutlet var tbviwe: UITableView!
    
    var str1 = "BTS"
    var int = 400
    var int2 = 2.32
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
      
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
            }

    @IBAction func actext1(sender: AnyObject) {
     
        var name = str1
    }
    
    @IBAction func actext2(sender: AnyObject) {
        var volume = int
        
        
    }
    
    @IBAction func actext3(sender: AnyObject) {
        var Price = int2
    }
    
    @IBAction func actext4(sender: AnyObject) {
        var Total = int * int2
    }
    
}

